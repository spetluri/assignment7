require_relative '../config/environment'

# A user has an account
puts "A user has an account\n\n"
user_account = User.first.account
puts("First Name: #{user_account.first_name} Last Name: #{user_account.last_name} Age: #{user_account.age} Gender: #{user_account.gender} User Id: #{user_account.user_id}\n\n")
puts
# A person has many to do lists
puts("A person has many to do lists\n\n")
User.first.todo_list.each do |list|
    puts "List Name: #{list.list_name}\nList Due Date: #{list.list_due_date}\n\n"
 end
puts
 # A todolist has many todo items
 puts("A to do list has many items\n\n")
 TodoList.last.todo_item.each do |item|
    puts "Due Date: #{item.due_date}\nTask Title: #{item.task_title}\nTask Description: #{item.description}\n\n"
 end
 puts
# A user has many to do items
puts "A user has many to do items\n\n"
User.first.todo_item.each do |item|
    puts "Due Date: #{item.due_date}\nTask Title: #{item.task_title}\nTask Description: #{item.description}\n\n"
end
#A tag has many todo items
puts("A tag has many todo items\n\n")
tag = Tag.second
puts("Tag Name: #{tag.tag_name}\n\n")
tag.todo_items.each do |item|
    puts "Due Date: #{item.due_date}\nTask Title: #{item.task_title}\nTask Description: #{item.description}\n\n"
end

puts("\n\n\n\n\n----------------------------------------------------------------------------------------\n\n\n\n\n")

=begin
In addition to being able to get to TodoItems from TodoLists, map
TodoItems directly on the User model (similar to how we mapped Salary to
Person in the lectures)
=end
puts "In addition to being able to get to TodoItems from TodoLists, map"
puts "TodoItems directly on the User model (similar to how we mapped Salary to"
puts "Person in the lectures)\n\n"
User.first.todo_item.to_a.each do |item|  
    puts "Due Date: #{item.due_date}\nTask Title: #{item.task_title}\nTask Description: #{item.description}\n\n"
end

puts("\n\n\n\n\n----------------------------------------------------------------------------------------\n\n\n\n\n")

=begin
Create a default scope for TodoItem that will return them in
due date ascending order (by default), so that I can see the ones due soon
first.
=end
puts "Create a default scope for TodoItem that will return them in"
puts "due date ascending order (by default), so that I can see the ones due soon"
puts "first.\n\n"
#Add to do items in unsorted order
puts("Adding two to do items in unsorted order\n\n")
User.first.todo_list.first.todo_item.create!(due_date: "2017-4-10",task_title: "Java Project", description: "Poker Simulation")
User.first.todo_list.first.todo_item.create!(due_date: "2016-5-31",task_title: "Hadoop Project", description: "Movie Data Calcuations")
#Dispay to do items in sorted order
puts("Printing to do items in sorted order\n\n")
User.first.todo_item.to_a.each do |item|
    puts "Due Date: #{item.due_date}\nTask Title: #{item.task_title}\nTask Description: #{item.description}\n\n"
end

puts("\n\n\n\n\n----------------------------------------------------------------------------------------\n\n\n\n\n")

=begin
Create a default scope for TodoList that will return them in
due date ascending order (by default), so that I can see the ones due soon
first.
=end
puts "Create a default scope for TodoList that will return them in"
puts "due date ascending order (by default), so that I can see the ones due soon"
puts "first.\n\n"

puts("To do list before any changes\n\n")
User.first.todo_list.each do |list|
    puts "List Name: #{list.list_name}\nList Due Date: #{list.list_due_date}\n\n"
end

 #Add to do lists in unsorted order
puts("Add two to do lists in unsorted order\n\n")
User.first.todo_list.create(list_name: "Video Games", list_due_date: "2026-06-06")
User.first.todo_list.create(list_name: "Poker Tournaments", list_due_date: "2010-06-06")
puts("Printing to do lists in sorted order\n\n")
User.first.todo_list.each do |list|
   puts "List Name: #{list.list_name}\nList Due Date: #{list.list_due_date}\n\n"
end

puts("\n\n\n\n\n----------------------------------------------------------------------------------------\n\n\n\n\n")

=begin
Validate that gender field (on Account model) only accepts: “male”, “female”
or “N/A” values and age field can only accept an integer between 20 and 100
for its input.
=end

puts 'Validate that gender field (on Account model) only accepts: “male”, “female”'
puts "or “N/A” values and age field can only accept an integer between 20 and 100"
puts "for its input.\n\n"

puts "Changing gender to Trans.\n\n"
begin
    account = User.first.account
    account.gender="Trans"
    account.save!
rescue Exception => ex
    puts ex
end

puts "Changing age to 19.\n\n"
begin
    account = User.first.account
    account.age=19
    account.save!
rescue Exception => ex
    puts ex
end

puts "Changing age to 101.\n\n"
begin
    account = User.first.account
    account.age=101
    account.save!
rescue Exception => ex
    puts ex
end



    