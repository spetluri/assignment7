class Account < ApplicationRecord
  belongs_to :user

  validates :gender, inclusion: { in: %w(male female N/A),
  message: "%{value} is not a valid gender" }

  validates :age, numericality: { in: 20..100 }

end
