class User < ApplicationRecord
    has_one :account, dependent: :destroy
    has_many :todo_list, dependent: :destroy
    has_many :todo_item, through: :todo_list, source: :todo_item
end
