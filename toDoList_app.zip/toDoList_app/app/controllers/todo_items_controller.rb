class TodoItemsController < ApplicationController

    before_action :set_todo_list, only: [:create, :destroy]

    def create
        @todo_item = @todo_list.todo_item.new(todo_item_params)
        if @todo_item.save
            redirect_to @todo_list, notice: 'Item sucessfully create.'
        else
            redirect_to @todo_list, alert: 'Unable to add a note.'

        end
    end

    def destroy
        @todo_item = @todo_list.todo_item.find(params[:id])
        @todo_item.destroy
        redirect_to @todo_list, notice: 'Item deleted.'
    end

    private

        def set_todo_list
            @todo_list = TodoList.find(params[:todo_list_id])
            puts @todo_list
            puts("PARAMETERS #{params}")
        end

        def todo_item_params
            puts("PARAMETERS IN TODO ITEM PARAMS #{params}")
            params.permit(:task_title, :description, :due_date)
        end
end
