# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

User.destroy_all
Account.destroy_all
TodoList.destroy_all
TodoItem.destroy_all
Tag.destroy_all

#   Create Users
u1 = User.create!(login: "Matt"     , password_digest:     "abc123"      )
u2 = User.create!(login: "Time"       , password_digest:     "abc123"     )
u3 = User.create!(login: "cashmoneykid1989" , password_digest:     "boxer"      )
u4 = User.create!(login: "princesspeaches2018" , password_digest:     "easel"      )

# Create Accounts
a1 = u1.create_account!(gender: "male", age: 32, first_name: "Sai", last_name: "Petluri")
a2 = u2.create_account!(gender: "female", age: 45, first_name: "Peaches", last_name: "Petluri")
a3 = u3.create_account!(gender: "N/A", age: 22, first_name: "Lil", last_name: "Wayne")
a4 = u4.create_account!(gender: "female", age: 99, first_name: "Marianna", last_name: "Luigi")

# Create To Do Lists
u1_tdl1 = u1.todo_list.create!(list_name: "Homework", list_due_date: "2022-12-31")
u1_tdl2 = u1.todo_list.create!(list_name: "Office", list_due_date: "2020-12-31")
u2_tdl1 = u2.todo_list.create!(list_name: "Personal", list_due_date: "2060-12-31")
u2_tdl2 = u2.todo_list.create!(list_name: "Bucket List", list_due_date: "2072-12-31")
u3_tdl1 = u3.todo_list.create!(list_name: "Legal Stuff", list_due_date: "2018-12-31")

# Create To Do Items for User 1 To Do List 1
u1_tdl1_tdi1 = u1_tdl1.todo_item.create!(due_date: "2022-3-31",task_title: "Rails To Do List Assignment", description: "Build Todolist WebApp")
u1_tdl1_tdi2 = u1_tdl1.todo_item.create!(due_date: "2052-4-30",task_title: "Calculus HW", description: "Odd problems Chapter 7")
u1_tdl1_tdi3 = u1_tdl1.todo_item.create!(due_date: "2022-5-30",task_title: "Physics Lab", description: "Series v Parallel Circuits")
u1_tdl1_tdi4 = u1_tdl1.todo_item.create!(due_date: "2018-6-30",task_title: "C++ Project", description: "Multiple Inheritance OOP")

# Create To Do Items for User 1 To Do List 2
u1_tdl2_tdi1 = u1_tdl2.todo_item.create!(due_date: "2022-3-31",task_title: "Board Meeting")
u1_tdl2_tdi2 = u1_tdl2.todo_item.create!(due_date: "2022-4-30",task_title: "Ruby on Rails Meet Up")
u1_tdl2_tdi3 = u1_tdl2.todo_item.create!(due_date: "2022-5-30",task_title: "Hopkins Networking Event", description: "JHU Whiting EP Recruitng Event")

# Create To Do Items for User 2 To Do List 1
u2_tdl1_tdi1 = u2_tdl1.todo_item.create!(due_date: "2022-3-31",task_title: "Wedding", description: "Wedding rings in safe")
u2_tdl1_tdi2 = u2_tdl1.todo_item.create!(due_date: "2022-4-15",task_title: "Honeymoon")
u2_tdl1_tdi3 = u2_tdl1.todo_item.create!(due_date: "2023-5-25",task_title: "Graduation Day")

# Create To Do Items for User 2 To Do List 1
u2_tdl2_tdi1 = u2_tdl2.todo_item.create!(due_date: "2022-4-15",task_title: "Bunjee Jumping")
u2_tdl2_tdi2 = u2_tdl2.todo_item.create!(due_date: "2023-5-25",task_title: "Sky Diving")

# Create To Do Items for User 3 To Do List 1
u3_tdl1_tdi1 = u3_tdl1.todo_item.create!(due_date: "2022-4-15",task_title: "Deposition")

# Create Tags
mex = Tag.create!(tag_name: "Mexico")
jhu = Tag.create!(tag_name: "JHU")
bbg = Tag.create!(tag_name: "Bloomberg LP")
prog = Tag.create!(tag_name: "Programming")

#Link Tags to To Do Items
u1_tdl1_tdi1.tags << jhu
u1_tdl1_tdi1.tags << prog
u1_tdl1_tdi1.tags << bbg

u1_tdl1_tdi2.tags << jhu
u1_tdl1_tdi3.tags << jhu
u1_tdl1_tdi4.tags << jhu

u1_tdl2_tdi1.tags << bbg
u1_tdl2_tdi2.tags << jhu
u1_tdl2_tdi2.tags << prog
u1_tdl2_tdi3.tags << jhu

u2_tdl1_tdi1.tags << mex
u2_tdl1_tdi2.tags << mex



